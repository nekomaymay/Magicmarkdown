// https://vitejs.dev/guide/features.html#typescript-compiler-options
/// <reference types="vite/client" />
